package com.example.myapplication252;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button Algebra = (Button) findViewById(R.id.Algebra);
        Algebra.setOnClickListener((View.OnClickListener) this);
    }
    public void onClick(View view) {
        Intent i;
        i=new Intent(this, Algebra.class);
        startActivity(i);
    }
    public void onClickk(View view) {
        Intent a;
        a=new Intent(this, Calcylator.class);
        startActivity(a);
    }
    public void  onClicсkk(View view){
        Intent q;
        q=new Intent(this, Gravity.class);
        startActivity(q);
    }

}